package com.example.exercicio_05

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
